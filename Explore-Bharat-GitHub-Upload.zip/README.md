# Explore Bharat

**One Nation. Endless Journeys.**

Explore Bharat is a responsive, single-page Indian tourism and cultural discovery website built with plain HTML, CSS and JavaScript. It is intended as a BCA student front-end project and a starting point for further development.

## Run locally

1. Download or clone this project.
2. Keep `index.html`, `style.css`, `script.js` and the `images/` folder together.
3. Open `index.html` in a browser. For the smoothest local development experience, use VS Code Live Server.

No build step, package manager or framework is required.

## Features

- Split-screen home hero using the supplied destination collage.
- 12 destination cards with four visible at a time on desktop, horizontal browsing, and a View All mode.
- Destination detail modal with attractions, experiences and practical notes.
- Eight culture categories powered by a JavaScript `switch-case` statement.
- Culture tiles with small top-right photos.
- Six travel-style choices that prefill the trip planner.
- Trip recommendations powered by `if / else if / else` logic.
- Registration form with browser validation and a front-end demo confirmation.
- Responsive desktop, tablet and mobile layouts.

## Image notes

The five images in `images/` were supplied by the project owner. Additional images are referenced from Wikimedia Commons and are credited in [`IMAGE-CREDITS.md`](IMAGE-CREDITS.md). The Commons images are hotlinked in this starter version so the site can be previewed without copying the large source files into the repository. A network connection is required to display those external images.

Before publishing, review the individual image licences in `IMAGE-CREDITS.md`. Some images are available under Creative Commons Attribution-ShareAlike licences, which require attribution and compatible sharing terms.

## GitHub Pages

This is a static website. To publish it, push the project to a GitHub repository and enable GitHub Pages from the repository's **Settings → Pages** area. Select **Deploy from a branch**, choose the default branch and `/ (root)`, then save. Because all local project assets use relative paths, the website can be served from a repository subpath.

## Important limitation

The registration form is only a front-end demonstration. It does not transmit or save personal information to a server, and it does not create a booking or accept payment. Do not enter real sensitive information into a demo deployment.
